
########################
#     READ ME          #
########################
This code.zip folder contains 3 .R files for replication of paper "Score-based tests of measurement invariance: Use in practice"
(Wang, Merkle & Zeileis). 

1. mz-frontiers.R:           Model estimation functions for simulations.
2. sim-frontiers.R:          Functions for data generation, power evaluation, and power summaries.
3. replication-frontiers.R:  Containing code to run and summarize the tutorial and simulations, using the above two files.


## Computational Details:

All results were obtained using the R system for statistical computing (R Core Team, 2013), version 3.0.3, employing the add-on package lavaan 0.5-15 (Rosseel, 2012) for fitting of the factor analysis models and strucchange 1.5-0 (Zeileis et al., 2002; Zeileis, 2006) for evaluating the parameter instability tests. R and both packages are freely available under the General Public License 2 from the Comprehensive R Archive Network at http://CRAN.R-project.org/. R code for replication of our results is also available at http://semtools.R-Forge.R-project.org/.
